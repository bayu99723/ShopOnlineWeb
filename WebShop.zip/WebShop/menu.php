<!DOCTYPE html>
<html>
<head>
	<title>Menu</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <style type="text/css">
    html {
      scroll-behavior: smooth;
    }
    .container {
      max-width: 800px;
      margin: 50px auto;
      padding: 20px;
      background-color: #fff;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

  footer {
      background-color: white;
      color: green;
      text-align: center;
      margin-top: 40px;
      margin-bottom: 40px;
    }
  </style>
</head>
<body>
		<?php include 'navbar.php';?>
    <br><br><br><br><br>
    <section id="about">
      <!-- About Section -->
      <div class="w3-row w3-padding-64" id="about">
        <div class="w3-col m6 w3-padding-large w3-hide-small">
        <img src="img/logo.png" class="w3-round w3-image w3-opacity-min" alt="Gambar" width="600" height="750" style="margin-left: 80px; margin-top: 280px;">
        </div>

        <div class="w3-col m6 w3-padding-large" style="margin-top: 80px;">
          <h1 class="w3-center">About Tokopedia</h1><br>
          <h5 class="w3-center">17 Mei 2021</h5>
          <p class="w3-large">PT Tokopedia adalah perusahaan e-commerce Indonesia. Tokopedia adalah anak perusahaan dari perusahaan induk baru bernama GoTo , setelah merger dengan Gojek pada 17 Mei 2021. Ini adalah salah satu platform e-commerce yang paling banyak dikunjungi di Indonesia. Tokopedia merupakan salah satu perusahaan unicorn di Indonesia , bersama dengan Bukalapak , Gojek , OVO , dan Traveloka. Pada Desember 2020, Tokopedia mengklaim memiliki lebih dari 350 juta listingan produk dan 42 produk digital, serta melayani lebih dari 100 juta pengguna aktif bulanan serta lebih dari 9,7 juta merchant di platformnya.</p>
          <p class="w3-large w3-text-grey w3-hide-medium">Ide Tokopedia dicetuskan oleh William Tanuwijaya dan Leontinus Alpha Edison pada tahun 2007. Saat merefleksikan pengalaman masa kecilnya, Tanuwijaya menyadari bahwa akses terhadap produk seperti buku berbeda antara kota kecil dan kota besar, dan bahwa teknologi dapat memberikan akses yang lebih baik terhadap produk. Duo ini meluncurkan Tokopedia dua tahun kemudian dengan modal awal dari seorang kenalan. Toko adalah bahasa Indonesia untuk "Toko", dan merupakan bagian pertama dari gabungan nama perusahaan, digabungkan dengan "ensiklopedia". Pemilihan sebutan ini mencerminkan tujuan mereka untuk menjadi pasar yang mencakup segalanya bagi masyarakat Indonesia. Tokopedia telah memperluas bisnisnya hingga mencakup sektor fintech , pembayaran, logistik , dan ritel. Sejak tahun 2017, kantor Tokopedia bertempat di gedung 53 lantai bernama Menara Tokopedia yang terletak di kawasan pusat bisnis Jakarta. Hingga tahun 2018, produk dan layanan Tokopedia diklaim dapat diakses di 93% kecamatan di seluruh Indonesia. Pada bulan Maret 2023, Tokopedia mengumumkan struktur manajemen barunya dengan Melissa Siska Juminto ditunjuk sebagai President of E-Commerce untuk Tokopedia dan Director/Chief Human Resources Officer untuk GoTo. Melissa sebelumnya menjabat sebagai COO Tokopedia sejak tahun 2018. Pada 11 Desember 2023, TikTok yang beroperasi di bawah ByteDance resmi mengumumkan akuisisi 75% saham Tokopedia. Investasi ini bernilai 1,5 miliar dolar AS atau sekitar 23,4 triliun Rupiah. Kolaborasi ini merupakan langkah TikTok untuk memperluas operasionalnya di sektor e-commerce Indonesia, khususnya melalui platform TikTok Shop. Meski TikTok kini memegang sebagian besar saham Tokopedia, namun 25% saham Tokopedia masih dipegang oleh GoTo, grup korporasi yang sebelumnya menaungi Tokopedia. Kerjasama ini tidak mempengaruhi kepemilikan saham Tokopedia di PT GoTo Gojek Tokopedia Tbk (GoTo). </p>
        </div>
      </div>
    </section>

    <section id="menu">
    <div class="container" style="margin-top: 140px;">
      <h1 style="margin-top: 20px;">Kami memiliki beberapa produk pilihan terbaik yang bisa kami sediakan</h1>
      <p style="font-size: 24px; margin-bottom: 50px;">Temukan berbagai produk berkualitas dengan harga terbaik.</p>
    
    <!-- Menu Pilihan -->
    <div class="row">
      <div class="col-sm-4 mb-3 mb-sm-0">
        <div class="card">
          <img src="..." class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Card title</h5>
              <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
              <a href="#" class="btn btn-danger">Buy Now</a>
            </div>
        </div>
      </div>

        <div class="col-sm-4">
          <div class="card">
            <img src="..." class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Card title</h5>
              <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
              <a href="#" class="btn btn-danger">Buy Now</a>
            </div>
          </div>
        </div>

        <div class="col-sm-4">
          <div class="card">
            <img src="..." class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Card title</h5>
              <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
              <a href="#" class="btn btn-danger">Buy Now</a>
            </div>
          </div>
        </div>

        <div class="col-sm-4" style="margin-top: 30px;">
          <div class="card">
            <img src="..." class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Card title</h5>
              <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
              <a href="#" class="btn btn-danger">Buy Now</a>
            </div>
          </div>
        </div>

        <div class="col-sm-4" style="margin-top: 30px;">
          <div class="card">
            <img src="..." class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Card title</h5>
              <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
              <a href="#" class="btn btn-danger">Buy Now</a>
            </div>
          </div>
        </div>

        <div class="col-sm-4" style="margin-top: 30px;">
          <div class="card">
            <img src="..." class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Card title</h5>
              <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
              <a href="#" class="btn btn-danger">Buy Now</a>
            </div>
          </div>
        </div>

        <div class="col-sm-4" style="margin-top: 30px;">
          <div class="card">
            <img src="..." class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Card title</h5>
              <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
              <a href="#" class="btn btn-danger">Buy Now</a>
            </div>
          </div>
        </div>

        <div class="col-sm-4" style="margin-top: 30px;">
          <div class="card">
            <img src="..." class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Card title</h5>
              <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
              <a href="#" class="btn btn-danger">Buy Now</a>
            </div>
          </div>
        </div>

        <div class="col-sm-4" style="margin-top: 30px;">
          <div class="card">
            <img src="..." class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Card title</h5>
              <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
              <a href="#" class="btn btn-danger">Buy Now</a>
            </div>
          </div>
        </div>
    </div>
  </div>
  </section>

  <footer>&copy; Copyright by Bayu & Piki </footer>
</body>
</html>