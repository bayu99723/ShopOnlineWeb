<!DOCTYPE html>
<html>
<head>
	<title>Menu</title>
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
</head>
<body>
		<!-- <nav class="navbar bg-dark border-bottom border-body" data-bs-theme="dark"> -->
		<div class="w3-top">
  		<div class="w3-bar w3-white w3-padding w3-card" style="letter-spacing:4px;">
    		<a href="#home" class="w3-bar-item" style="color: green; text-decoration: none;">Takapedia</a>
    		<a href="#home" class="w3-bar-item w3-button">Kategori</a>
    		<a><input type="text" placeholder="Search.." style="margin-top: 6px; width: 665px; margin-left: 20px;"></a>
    		<a href="#home"><i class="fa fa-shopping-cart w3-margin-right"></i></a>
    		<!-- Right-sided navbar links. Hide them on small screens -->
    		<div class="w3-right w3-hide-small">
      			<a href="#about" class="w3-bar-item w3-button">About</a>
      			<a href="menu.php" class="w3-bar-item w3-button">Menu</a>
      			<a href="#contact" class="w3-bar-item w3-button">Contact</a>
    		</div>
  		</div>
</body>
</html>