<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Utama</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            text-align: center;
        }
        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: #333;
        }
        p {
            color: #666;
            line-height: 1.6;
        }
        .buy-button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s;
        }
        .buy-button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
  <?php include 'navbar.php';?><br><br><br><br><br><br><br><br><br>
    <div class="container">
      <div id="carouselExampleIndicators" class="carousel slide">
      <div class="carousel-indicators">
        <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
        <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
        <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
      </div>
      <div class="carousel-inner">
        <div class="carousel-item active">
            <img src="img/iklan1.png" class="d-block w-100" alt="...">
        </div>
        <div class="carousel-item">
            <img src="img/iklan2.jpg" class="d-block w-100" alt="..." style="height: 555px;">
        </div>
        <div class="carousel-item">
            <img src="img/iklan3.jpg" class="d-block w-100" alt="..." style="height: 555px;">
        </div>
      </div>
      <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
      </button>
      <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
      </button>
    </div>
        <h1 style="margin-top: 20px;">Selamat Datang di Toko Online Kami</h1>
        <p style="font-size: 20px;">Temukan berbagai produk berkualitas dengan harga terbaik. Segera belanja sekarang!</p>
        <a href="menu.php #menu" class="btn btn-info">Mulai Belanja</a>
    </div>

    <div class="w3-bar w3-white w3-padding w3-card" style="letter-spacing:4px;">
      <footer>
        <p align="center" style="color: green;">&copy; Copyright by Bayu & Piki</p>
      </footer>
    </div>

</body>
</html>