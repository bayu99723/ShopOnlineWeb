<?php
// Include config file
require_once "config.php";

// Define variables and initialize with empty values
$nama = $alamat = $email = $pesan = "";
$nama_err = $alamat_err = $email_err = $pesan_err="";

// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
    // Validate nama
    $input_nama = trim($_POST["nama"]);
    if(empty($input_nama)){
        $nama_err = "Nama tidak boleh kosong";
    } else{
        $nama = $input_nama;
    }

    // Validate nama alamat notes
    $input_alamat = trim($_POST["alamat"]);
    if(empty($input_alamat)){
        $alamat_err = "Alamat tidak boleh kosong";
    } else{
        $alamat = $input_alamat;
    }

    // Validate nama
    $input_email = trim($_POST["email"]);
    if(empty($input_email)){
        $email_err = "Email tidak boleh kosong";
    } else{
        $email = $input_email;
    }

    // Validate pesan
    $input_pesan = trim($_POST["pesan"]);
    if(empty($input_pesan)){
        $pesan_err = "Pesan tidak boleh kosong";
    } else{
        $pesan = $input_pesan;
    }

    // Check input errors before inserting in database
    if(empty($nama_err) && empty($alamat_err) && empty($email_err) && empty($pesan_err)){
        // Prepare an insert statement
        $sql = "INSERT INTO bukutamu (nama, alamat, email, pesan) VALUES (?, ?, ?, ?)";

        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ssss", $param_nama, $param_alamat, $param_email, $param_pesan);

            // Set parameters
            $param_nama = $nama;
            $param_alamat = $alamat;
            $param_email = $email;
            $param_pesan = $pesan;

            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Records created successfully. Redirect to landing page
                header("location: bukutamu.php");
                exit();
            } else{
                echo "Something went wrong. Please try again later.";
            }
        }

        // Close statement
        mysqli_stmt_close($stmt);
    }

    // Close connection
    mysqli_close($link);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create alamat</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.js"></script>
    
    <style type="text/css">
        .wrapper{
            width: 650px;
            margin: 0 auto;
        }
        .page-header h2{
            margin-top: 0;
        }
        table tr td:last-child a{
            margin-right: 15px;
        }
    </style>
    <script type="text/javascript">
        $(document).ready(function(){
            $('[data-toggle="tooltip"]').tooltip();
        });
    </script>
</head>
<body>
    <?php include 'menu.php';?>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2 class="pull-left">Buku Tamu</h2>
                        <!-- <a href="logout.php" class="btn btn-success pull-right">Logout</a> -->
                    </div>
                    <br>
                    <p>Isi Buku Tamu untuk mengetahui keterangan lebih lanjut</p>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        <div class="form-group <?php echo (!empty($nama_err)) ? 'has-error' : ''; ?>">
                            <label>Nama</label>
                            <input type="text" name="nama" class="form-control" value="<?php echo $nama; ?>">
                            <span class="help-block"><?php echo $nama_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($alamat_err)) ? 'has-error' : ''; ?>">
                            <label>Alamat</label>
                            <input type="text" name="alamat" class="form-control" value="<?php echo $alamat; ?>">
                            <span class="help-block"><?php echo $alamat_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($email_err)) ? 'has-error' : ''; ?>">
                            <label>Email</label>
                            <input type="text" name="email" class="form-control" value="<?php echo $email; ?>">
                            <span class="help-block"><?php echo $email_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($pesan_err)) ? 'has-error' : ''; ?>">
                            <label>Pesan</label>
                            <input type="text" name="pesan" class="form-control" value="<?php echo $pesan; ?>">
                            <span class="help-block"><?php echo $pesan_err;?></span>
                        </div>
                        <input type="submit" class="btn btn-primary" value="Submit" href="wa/083842803207">
                        <!-- <a href="tampil.php" class="btn btn-success">Tampil</a> -->
                        <!-- <a href="index.php" class="btn btn-default">Cancel</a> -->
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>