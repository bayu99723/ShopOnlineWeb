<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "contoh_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// sql to create table
$sql = "CREATE TABLE tabel_input (
id INT(20) AUTO_INCREMENT PRIMARY KEY,
nama VARCHAR(30) NOT NULL,
alamat VARCHAR(30) NOT NULL,
instansi VARCHAR(50) NOT NULL,
no_telp INT(50) NOT NULL
)";

if ($conn->query($sql) === TRUE) {
  echo "Table_input created successfully";
} else {
  echo "Error creating table: " . $conn->error;
}

$conn->close();
?>